const global = {
    owner: [7093265853], // ganti jadi id mu
    botToken: "8024896177:AAHDWF8_r9UeZPNftiF9S6Hlz4VV3KzCSHU", //isi make token bot mu
}

module.exports = global;