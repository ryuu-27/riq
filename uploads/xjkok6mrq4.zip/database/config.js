module.exports = {
  tokens: "8540797861:AAHAcKih21R1dx2kXu4j9mhwFNRKNTMVEOw",  // Ubah Jadi Token Bot Mu !!!
  owner: "7366293972", // Ubah Jadi Id Mu !!!
  port: "2000", // Ubah Jadi Port Panel Mu !!!
  ipvps: "http://cimzy.bot-wangsaf.my.id" // Ubah Jadi Ip Vps Mu !!!
};