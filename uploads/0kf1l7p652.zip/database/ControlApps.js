module.exports = {
  tokens: "8508711860:AAEeSsu8AUBZekmI62f6Z5mcdXJkvZQZiIY", 
  owner: "7464121207", 
  port: "9362", // Ini Wajib Jangan Diubah
  ipvps: "https://host.astavvip-tech.xyz" // Jangan Diubah Nanti Eror!!
};