module.exports = {
  BOT_TOKEN: "7529009982:AAHi_W6mTgO-2Dc1xa-vOIQ0sMC6bjzGVIs",
    allowedDevelopers: ['8140918981'], // ID
};